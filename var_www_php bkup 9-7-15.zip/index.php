<?php
    session_start();
    include_once('header.php');
    include_once('functions.php');

    $_SESSION['userid'] = 1;
?>
<!DOCTYPE html>
<html>
    <head>
        <title>Pearse's Digital Ocean Test Page</title>
    </head>
    <body>
        <?php
            if(isset($_SESSION['message'])) {
                echo "<b>" . $_SESSION['message'] . "</b>";
                unset($_SESSION['message']);
            }
        ?>
        <form method='post' action='add.php'>
        <p>Your status:</p>
        <textarea name='body' rows='5' cols='40' wrap=VIRTUAL></textarea>
        <p><input type='submit' value='submit'></p>
        </form>

        <?php
            $users = show_users($_SESSION['userid']);
            if(count($users)) {
                $myusers = array_keys($users);
            }
            else {
                $myusers = array();
            }
            $myusers[] = $_SESSION['userid'];

            $posts = show_posts($myusers, 3);

            if (count($posts)){
                ?>
                <table border='1' cellspacing='0' cellpadding='5' width='500'>
                    <?php
                        foreach ($posts as $key => $list){
                            echo "<tr valign='top'>\n";
                            echo "<td>".$list['userid'] ."</td>\n";
                            echo "<td>".$list['body'] ."<br/>\n";
                            echo "<small>".$list['stamp'] ."</small></td>\n";
                            echo "</tr>\n";
                        }
                    ?>
                </table>
            <?php
                } else {
            ?>
                <p><b>You haven't posted anything yet!</b></p>
            <?php
                }
            ?>
    <p><a href='users.php'>see list of users</a></p>
    <h2>Users you're following</h2>

    <?php
        

        if(count($users)) {
            echo "<ul>";
            foreach($users as $key => $value) {
                echo "<li>" . $value . "</li>\n";
            }
            echo "</ul>";
        }
        else {
            echo "<p><b>You're not following anyone yet!</b></p>";
        }
    ?>
    </body>
</html>